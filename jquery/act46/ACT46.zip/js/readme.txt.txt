this file is here because compressed files cannot have empty folders hehe

if you see this file, add the following comment at the top of your js file for +2 points:

//found it!